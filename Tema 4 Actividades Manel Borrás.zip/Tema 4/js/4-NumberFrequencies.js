
let lista = [];

    for (let i = 0; i < 10000; i++) {
        let num = parseInt(Math.random()*10+1);
        lista.push(num);    
    }
let counter1 = 0;
let counter2 = 0;
let counter3 = 0;
let counter4 = 0;
let counter5 = 0;
let counter6 = 0;
let counter7 = 0;
let counter8 = 0;
let counter9 = 0;
let counter10 = 0;

    for (value of lista) {
      switch (value) {
        case 1:
            counter1++;
            break;
        case 2:
            counter2++;
            break;
        case 3:
            counter3++;
            break;
        case 4:
            counter4++;
            break;
        case 5:
            counter5++;
            break;
        case 6:
            counter6++;
            break;    
            
        case 7:
            counter7++;
            break;
            
        case 8:
            counter8++;
            break;
            
        case 9:
            counter9++;
            break;
            
        case 10:
            counter10++;
            break;
        default:
            break;
      }
    };


    document.write("El numero 1 se repite: "+counter1+" veces");
    document.write("<br>");
    document.write("El numero 2 se repite: "+counter2+" veces");
    document.write("<br>");
    document.write("El numero 3 se repite: "+counter3+" veces");
    document.write("<br>");
    document.write("El numero 4 se repite: "+counter4+" veces");
    document.write("<br>");
    document.write("El numero 5 se repite: "+counter5+" veces");
    document.write("<br>");
    document.write("El numero 6 se repite: "+counter6+" veces");
    document.write("<br>");
    document.write("El numero 7 se repite: "+counter7+" veces");
    document.write("<br>");
    document.write("El numero 8 se repite: "+counter8+" veces");
    document.write("<br>");
    document.write("El numero 9 se repite: "+counter9+" veces");
    document.write("<br>");
    document.write("El numero 10 se repite: "+counter10+" veces");
