console.log("Hello");

var x = "hola" * 3;
console.log(x);