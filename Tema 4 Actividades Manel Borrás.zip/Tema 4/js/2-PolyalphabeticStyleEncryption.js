//We setup the variables
let palabra = prompt("Dime una palabra para encriptar: ");
let key = prompt("Dime la llave de encriptación");
let lista = [];
let j = 0;
//start the for bucle for encrypting the text
for (let index = 0; index < palabra.length; index++) {
parseInt(j);

    if (j >= palabra.length) {
        j = 0;
    }

    //Convert the word to a ascii code for each letter
    let letra = palabra.charCodeAt(index);
    //Adds the ascii code of the letter plus the key 
    let charEncrypted = String.fromCharCode(letra + parseInt(key.charAt(j)));
    //Saves the encrypted char in an array
    lista.push(charEncrypted);
    console.log(j);
    j++;
}
    //Transforms the array to a string
    palabraEncr = lista.toString();
    //Shows the encrypted array
    alert("La palabra encriptada es: "+lista.join(""));