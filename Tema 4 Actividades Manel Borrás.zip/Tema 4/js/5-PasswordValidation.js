function script(){
    let name = document.getElementById("name").value;
    let key = document.getElementById("key").value;
}

