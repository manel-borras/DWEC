let tickets = [];
let numbers = [];

for (let i = 0; i < 50; i++) {
        numbers = [];

    do {
        let random = parseInt(Math.random()*48+1);


    if (numbers.includes(random))
        continue;
        
    numbers.push(random);

    } while (numbers.length < 6);
    
    tickets.push(numbers);
}

for(let index in tickets){
    
    document.write("<h3>"+index+"</h3>");
    document.write("Combinación: "+tickets[index])
    document.write("<br>");  
}