//Ejercicio 1
let x = 19;
    {
        let x = 16;
    }
console.log(x);


/* Ejercicio 2
var y = 0;
var x = 5;

x += 9;

console.log("x += 9 vale: "+x);

y = x++;

console.log("y = x++ vale: "+y);

console.log(y);

y = --x;

console.log("y = --x vale: "+y);
*/