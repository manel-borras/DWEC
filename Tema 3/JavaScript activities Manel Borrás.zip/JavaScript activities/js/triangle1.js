numero = parseInt(numero);

if (numero > 0){
    for (let index = 0; index < numero; index++) {

        for(let f = 0 ; f <= index ; f++){
            document.write("*");
        }
        document.write("<br>");
    }

}else if (numero <= 0) {

} else if (isNaN){

}



