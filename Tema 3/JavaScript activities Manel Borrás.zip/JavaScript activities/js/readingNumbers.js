if (!isNaN(numero)) {
    alert("Es un numero");
} else {
    alert("No es un numero");
}