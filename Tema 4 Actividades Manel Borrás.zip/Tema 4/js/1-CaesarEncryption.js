
let palabra = prompt("Dime una palabra para encriptar: ");
let key = parseInt(prompt("Dime la llave de encriptación"));
let lista = [];

for (let index = 0; index < palabra.length; index++) {
    let letra = (palabra.charAt(index));
    let num = letra.charCodeAt(0);
    let charEncrypted = String.fromCharCode(num + key);

    lista.push(charEncrypted);
}

    palabraEncr = lista.toString();
    alert("La palabra encriptada es: "+lista.join(""));

