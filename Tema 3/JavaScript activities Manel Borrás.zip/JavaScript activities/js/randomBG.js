
    var x = Math.random() * 256;
    var y = Math.random() * 256;
    var z = Math.random() * 256;
    var bgColor = "rgb(" + x + "," + y + "," + z + ")";
 console.log(bgColor);

    document.body.style.background = bgColor;


random_bg_color();